package game.player.agent;

import game.session.controller.Direction;
import game.structure.cell.Cell;
import game.structure.map.GameMap;
//TODO algoritmo del giocatore automatico a punteggio
public class ScoreAgent extends BasicAgent{

	@Override
	public void chooseMove(GameMap em, GameMap gm) {
		// TODO Auto-generated method stub

	}

	@Override
	public Direction chooseDirection(int i, int j, GameMap em) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
